package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;
import br.com.davi.data.model.Order;
import br.com.davi.data.vo.v1.OrderVO;
import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.OrderRepository;

@Service
public class OrderServices {
	
	@Autowired
	OrderRepository repository;
		
	public OrderVO create(OrderVO order) {
		var entity = DozerConverter.parseObject(order, Order.class);
		var vo = DozerConverter.parseObject(repository.save(entity), OrderVO.class);
		return vo;
	}
	
	public List<OrderVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), OrderVO.class);
	}	
	
	public OrderVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, OrderVO.class);
	}
		
	public OrderVO update(OrderVO order) {
		var entity = repository.findById(order.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setCart(order.getCart());
		entity.setPerson(order.getPerson());
		entity.setSubtotal(order.getSubtotal());

		
		var vo = DozerConverter.parseObject(repository.save(entity), OrderVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		Order entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this  ID"));
		repository.delete(entity);
	}

}
