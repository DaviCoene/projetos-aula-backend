package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;
import br.com.davi.data.model.Product;
import br.com.davi.data.vo.v1.ProductVO;
import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.ProductRepository;


@Service
public class ProductServices {
	
	@Autowired
	ProductRepository repository;
		
	public ProductVO create(ProductVO product) {
		var entity = DozerConverter.parseObject(product, Product.class);
		var vo = DozerConverter.parseObject(repository.save(entity), ProductVO.class);
		return vo;
	}
	
	public List<ProductVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), ProductVO.class);
	}	
	
	public ProductVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, ProductVO.class);
	}
		
	public ProductVO update(ProductVO product) {
		var entity = repository.findById(product.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setDescrition(product.getDescrition());
		entity.setImage(product.getDescrition());
		entity.setPrice(product.getPrice());
		entity.setName(product.getName());
		
		var vo = DozerConverter.parseObject(repository.save(entity), ProductVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		Product entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		repository.delete(entity);
	}

}
