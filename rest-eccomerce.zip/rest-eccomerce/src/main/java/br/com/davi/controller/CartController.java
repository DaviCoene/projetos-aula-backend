package br.com.davi.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.davi.data.vo.v1.CartVO;
import br.com.davi.services.CartServices;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "CartEndpoint")
@RestController
@RequestMapping("/api/cart/v1")
public class CartController {
	
	@Autowired
	private CartServices service;
	
	@ApiOperation(value = "Find all carts" ) 
	@GetMapping(produces = { "application/json", "application/xml", "application/x-yaml" })
	public List<CartVO> findAll() {
		List<CartVO> carts =  service.findAll();
		carts
			.stream()
			.forEach(p -> p.add(
					linkTo(methodOn(CartController.class).findById(p.getKey())).withSelfRel()
				)
			);
		return carts;	
	}	
	
	@ApiOperation(value = "Find a specific cart by your ID" )
	@GetMapping(value = "/{id}", produces = { "application/json", "application/xml", "application/x-yaml" })
	public CartVO findById(@PathVariable("id") Long id) {
		CartVO cartVO = service.findById(id);
		cartVO.add(linkTo(methodOn(CartController.class).findById(id)).withSelfRel());
		return cartVO;
	}	
	
	
	
	@ApiOperation(value = "Create a new cart") 
	@PostMapping(produces = { "application/json", "application/xml", "application/x-yaml" }, 
			consumes = { "application/json", "application/xml", "application/x-yaml" })
	public CartVO create(@RequestBody CartVO cart) {
		CartVO cartVO = service.create(cart);
		cartVO.add(linkTo(methodOn(CartController.class).findById(cartVO.getKey())).withSelfRel());
		return cartVO;
	}
	
	@ApiOperation(value = "Update a specific cart")
	@PutMapping(produces = { "application/json", "application/xml", "application/x-yaml" }, 
			consumes = { "application/json", "application/xml", "application/x-yaml" })
	public CartVO update(@RequestBody CartVO cart) {
		CartVO cartVO = service.update(cart);
		cartVO.add(linkTo(methodOn(CartController.class).findById(cartVO.getKey())).withSelfRel());
		return cartVO;
	}	
	
	@ApiOperation(value = "Delete a specific cart by your ID")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") Long id) {
		service.delete(id);
		return ResponseEntity.ok().build();
	}	
	
}