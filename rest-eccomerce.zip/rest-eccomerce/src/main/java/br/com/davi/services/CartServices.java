package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;
import br.com.davi.data.model.Cart;
import br.com.davi.data.vo.v1.CartVO;
import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.CartRepository;


@Service
public class CartServices {
	
	@Autowired
	CartRepository repository;
		
	public CartVO create(CartVO cart) {
		var entity = DozerConverter.parseObject(cart, Cart.class);
		var vo = DozerConverter.parseObject(repository.save(entity), CartVO.class);
		return vo;
	}
	
	public List<CartVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), CartVO.class);
	}	
	
	public CartVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, CartVO.class);
	}
		
	public CartVO update(CartVO cart) {
		var entity = repository.findById(cart.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setProducts(cart.getProducts());

		
		var vo = DozerConverter.parseObject(repository.save(entity), CartVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		Cart entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		repository.delete(entity);
	}

}
