package br.com.davi.converter.mocks;

import java.util.ArrayList;
import java.util.List;

import br.com.davi.data.model.Stock;
import br.com.davi.data.vo.v1.StockVO;

public class MockPerson {


    public Stock mockEntity() {
    	return mockEntity(0);
    }
    
    public StockVO mockVO() {
    	return mockVO(0);
    }
    
    public List<Stock> mockEntityList() {
        List<Stock> persons = new ArrayList<Stock>();
        for (int i = 0; i < 14; i++) {
            persons.add(mockEntity(i));
        }
        return persons;
    }

    public List<StockVO> mockVOList() {
        List<StockVO> persons = new ArrayList<>();
        for (int i = 0; i < 14; i++) {
            persons.add(mockVO(i));
        }
        return persons;
    }
    
    private Stock mockEntity(Integer number) {
    	Stock person = new Stock();

        person.setId(number.longValue());

        return person;
    }

    private StockVO mockVO(Integer number) {
    	StockVO person = new StockVO();

        person.setKey(number.longValue());

        return person;
    }

}
