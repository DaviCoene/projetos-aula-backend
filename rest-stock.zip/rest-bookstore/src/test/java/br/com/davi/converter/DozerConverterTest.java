package br.com.davi.converter;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.davi.converter.DozerConverter;
import br.com.davi.converter.mocks.MockPerson;
import br.com.davi.data.model.Stock;
import br.com.davi.data.vo.v1.StockVO;

public class DozerConverterTest {
	
    MockPerson inputObject;

    @Before
    public void setUp() {
        inputObject = new MockPerson();
    }

    @Test
    public void parseEntityToVOTest() {
        StockVO output = DozerConverter.parseObject(inputObject.mockEntity(), StockVO.class);
        Assert.assertEquals(Long.valueOf(0L), output.getKey());

    }

    @Test
    public void parseEntityListToVOListTest() {
        List<StockVO> outputList = DozerConverter.parseListObjects(inputObject.mockEntityList(), StockVO.class);
        StockVO outputZero = outputList.get(0);
        
        Assert.assertEquals(Long.valueOf(0L), outputZero.getKey());

        
        StockVO outputSeven = outputList.get(7);
        
        Assert.assertEquals(Long.valueOf(7L), outputSeven.getKey());

        
        StockVO outputTwelve = outputList.get(12);
        
        Assert.assertEquals(Long.valueOf(12L), outputTwelve.getKey());

    }

    @Test
    public void parseVOToEntityTest() {
        Stock output = DozerConverter.parseObject(inputObject.mockVO(), Stock.class);
        Assert.assertEquals(Long.valueOf(0L), output.getId());

    }

    @Test
    public void parserVOListToEntityListTest() {
        List<Stock> outputList = DozerConverter.parseListObjects(inputObject.mockVOList(), Stock.class);
        Stock outputZero = outputList.get(0);

    }
}
