﻿INSERT INTO `permission` (`description`) VALUES
	('ADMIN'),
	('MANAGER'),
	('COMMON_USER');