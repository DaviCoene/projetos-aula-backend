package Enum;

public enum TypeMovement {
	ENTRADA,SAIDA
}
