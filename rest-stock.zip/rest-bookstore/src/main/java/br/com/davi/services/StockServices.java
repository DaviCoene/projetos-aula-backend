package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;
import br.com.davi.data.model.Stock;
import br.com.davi.data.vo.v1.StockVO;
import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.StockRepository;


@Service
public class StockServices {
	
	@Autowired
	StockRepository repository;
		
	public StockVO create(StockVO stock) {
		var entity = DozerConverter.parseObject(stock, Stock.class);
		var vo = DozerConverter.parseObject(repository.save(entity), StockVO.class);
		return vo;
	}
	
	public List<StockVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), StockVO.class);
	}	
	
	public StockVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, StockVO.class);
	}
		
	public StockVO update(StockVO stock) {
		var entity = repository.findById(stock.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setLocalization(stock.getLocalization());
		

		
		var vo = DozerConverter.parseObject(repository.save(entity), StockVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		Stock entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		repository.delete(entity);
	}

}
