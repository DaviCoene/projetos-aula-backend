package br.com.davi.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.davi.data.vo.v1.ReportStockVO;
import br.com.davi.data.vo.v1.StockVO;
import br.com.davi.services.ReportStockServices;
import br.com.davi.services.StockServices;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "ReportStockEndpoint")
@RestController
@RequestMapping("/api/reportstock/v1")
public class ReportStockController {
	
	@Autowired
	private ReportStockServices service;
	
	@ApiOperation(value = "Find all reportstock" ) 
	@GetMapping(produces = { "application/json", "application/xml", "application/x-yaml" })
	public List<ReportStockVO> findAll() {
		List<ReportStockVO> persons =  service.findAll();
		persons
			.stream()
			.forEach(p -> p.add(
					linkTo(methodOn(ReportStockController.class).findById(p.getKey())).withSelfRel()
				)
			);
		return persons;
	}	
	
	@ApiOperation(value = "Find a specific reportstock by your ID" )
	@GetMapping(value = "/{id}", produces = { "application/json", "application/xml", "application/x-yaml" })
	public ReportStockVO findById(@PathVariable("id") Long id) {
		ReportStockVO personVO = service.findById(id);
		personVO.add(linkTo(methodOn(ReportStockController.class).findById(id)).withSelfRel());
		return personVO;
	}	

	@ApiOperation(value = "Create a new reportstock") 
	@PostMapping(produces = { "application/json", "application/xml", "application/x-yaml" }, 
			consumes = { "application/json", "application/xml", "application/x-yaml" })
	public ReportStockVO create(@RequestBody ReportStockVO person) {
		ReportStockVO personVO = service.create(person);
		personVO.add(linkTo(methodOn(ReportStockController.class).findById(personVO.getKey())).withSelfRel());
		return personVO;
	}
	
	@ApiOperation(value = "Update a specific reportstock")
	@PutMapping(produces = { "application/json", "application/xml", "application/x-yaml" }, 
			consumes = { "application/json", "application/xml", "application/x-yaml" })
	public ReportStockVO update(@RequestBody ReportStockVO person) {
		ReportStockVO personVO = service.update(person);
		personVO.add(linkTo(methodOn(ReportStockController.class).findById(personVO.getKey())).withSelfRel());
		return personVO;
	}	
	
	@ApiOperation(value = "Delete a specific reportstock by your ID")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") Long id) {
		service.delete(id);
		return ResponseEntity.ok().build();
	}	
	
}