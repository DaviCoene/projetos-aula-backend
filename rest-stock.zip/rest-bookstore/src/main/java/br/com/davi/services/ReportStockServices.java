package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;

import br.com.davi.data.model.StockMovement;
import br.com.davi.data.model.ReportStock;
import br.com.davi.data.vo.v1.ReportStockVO;
import br.com.davi.data.vo.v1.StockMovementVO;

import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.ReportStockRepository;
import br.com.davi.repository.StockMovementRepository;


@Service
public class ReportStockServices {
	
	@Autowired
	ReportStockRepository repository;
		
	public ReportStockVO create(ReportStockVO reportstock) {
		var entity = DozerConverter.parseObject(reportstock, ReportStock.class);
		var vo = DozerConverter.parseObject(repository.save(entity), ReportStockVO.class);
		return vo;
	}
	
	public List<ReportStockVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), ReportStockVO.class);
	}	
	
	public ReportStockVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, ReportStockVO.class);
	}
		
	public ReportStockVO update(ReportStockVO reportstock) {
		var entity = repository.findById(reportstock.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setLocalization(reportstock.getLocalization());
		entity.setProducts(reportstock.getProducts());
		
		
		var vo = DozerConverter.parseObject(repository.save(entity),ReportStockVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		ReportStock entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		repository.delete(entity);
	}
}
