package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;
import br.com.davi.data.model.Supplier;
import br.com.davi.data.vo.v1.SupplierVO;
import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.SupplierRepository;

@Service
public class SupplierServices {
	
	@Autowired
	SupplierRepository repository;
		
	public SupplierVO create(SupplierVO order) {
		var entity = DozerConverter.parseObject(order, Supplier.class);
		var vo = DozerConverter.parseObject(repository.save(entity), SupplierVO.class);
		return vo;
	}
	
	public List<SupplierVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), SupplierVO.class);
	}	
	
	public SupplierVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, SupplierVO.class);
	}
		
	public SupplierVO update(SupplierVO supplier) {
		var entity = repository.findById(supplier.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setContact(supplier.getContact());
		entity.setName(supplier.getName());
		entity.setProduct(supplier.getProduct());
		
		

		
		var vo = DozerConverter.parseObject(repository.save(entity), SupplierVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		Supplier entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this  ID"));
		repository.delete(entity);
	}

}
