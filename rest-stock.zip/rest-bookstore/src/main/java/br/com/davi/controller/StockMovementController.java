package br.com.davi.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import br.com.davi.data.vo.v1.StockMovementVO;
import br.com.davi.services.StockMovementServices;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "StockMovementEndpoint")
@RestController
@RequestMapping("/api/stockmovement/v1")
public class StockMovementController {
	
	@Autowired
	private StockMovementServices service;
	
	@ApiOperation(value = "Find all stockmovements" ) 
	@GetMapping(produces = { "application/json", "application/xml", "application/x-yaml" })
	public List<StockMovementVO> findAll() {
		List<StockMovementVO> orders =  service.findAll();
		orders
			.stream()
			.forEach(p -> p.add(
					linkTo(methodOn(StockMovementController.class).findById(p.getKey())).withSelfRel()
				)
			);
		return orders;	
	}	
	
	@ApiOperation(value = "Find a specific stockmovement by your ID" )
	@GetMapping(value = "/{id}", produces = { "application/json", "application/xml", "application/x-yaml" })
	public StockMovementVO findById(@PathVariable("id") Long id) {
		StockMovementVO orderVO = service.findById(id);
		orderVO.add(linkTo(methodOn(StockMovementController.class).findById(id)).withSelfRel());
		return orderVO;
	}	
	
	
	
	@ApiOperation(value = "Create a new stockmovement") 
	@PostMapping(produces = { "application/json", "application/xml", "application/x-yaml" }, 
			consumes = { "application/json", "application/xml", "application/x-yaml" })
	public StockMovementVO create(@RequestBody StockMovementVO order) {
		StockMovementVO orderVO = service.create(order);
		orderVO.add(linkTo(methodOn(StockMovementController.class).findById(orderVO.getKey())).withSelfRel());
		return orderVO;
	}
	
	@ApiOperation(value = "Update a specific stockmovement")
	@PutMapping(produces = { "application/json", "application/xml", "application/x-yaml" }, 
			consumes = { "application/json", "application/xml", "application/x-yaml" })
	public StockMovementVO update(@RequestBody StockMovementVO order) {
		StockMovementVO orderVO = service.update(order);
		orderVO.add(linkTo(methodOn(StockMovementController.class).findById(orderVO.getKey())).withSelfRel());
		return orderVO;
	}	
	
	@ApiOperation(value = "Delete a specific order by your ID")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") Long id) {
		service.delete(id);
		return ResponseEntity.ok().build();
	}	
	
}