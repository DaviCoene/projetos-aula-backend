package br.com.davi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.davi.converter.DozerConverter;

import br.com.davi.data.model.StockMovement;
import br.com.davi.data.vo.v1.StockMovementVO;

import br.com.davi.exception.ResourceNotFoundException;
import br.com.davi.repository.StockMovementRepository;


@Service
public class StockMovementServices {
	
	@Autowired
	StockMovementRepository repository;
		
	public StockMovementVO create(StockMovementVO person) {
		var entity = DozerConverter.parseObject(person, StockMovement.class);
		var vo = DozerConverter.parseObject(repository.save(entity), StockMovementVO.class);
		return vo;
	}
	
	public List<StockMovementVO> findAll() {
		return DozerConverter.parseListObjects(repository.findAll(), StockMovementVO.class);
	}	
	
	public StockMovementVO findById(Long id) {

		var entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		return DozerConverter.parseObject(entity, StockMovementVO.class);
	}
		
	public StockMovementVO update(StockMovementVO stockmovement) {
		var entity = repository.findById(stockmovement.getKey())
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		
		entity.setDateMovement(stockmovement.getDateMovement());
		entity.setProducts(stockmovement.getProducts());
		entity.setQuantity(stockmovement.getQuantity());
		entity.setTypeMovemet(stockmovement.getTypeMovemet());
		
		
		var vo = DozerConverter.parseObject(repository.save(entity),StockMovementVO.class);
		return vo;
	}	
	
	public void delete(Long id) {
		StockMovement entity = repository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No records found for this ID"));
		repository.delete(entity);
	}
}
